package com.tugberka.mdsflutter_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
