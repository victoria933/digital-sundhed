#import <Flutter/Flutter.h>

@interface MdsflutterPlugin : NSObject<FlutterPlugin>
@end
